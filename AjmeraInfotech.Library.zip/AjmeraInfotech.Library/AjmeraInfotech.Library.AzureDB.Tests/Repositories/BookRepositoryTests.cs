﻿using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.AzureDB.Repositories;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AjmeraInfotech.Library.Common.Models.Request;
using AjmeraInfotech.Library.Domain.Entities;
using AutoMapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AzureDB.Tests.Repositories
{
    [TestClass]
    public class BookRepositoryTests
    {
        private readonly Mock<IGenericRepository<Book>> _repositoryMock = new Mock<IGenericRepository<Book>>();
        private readonly Mock<IMapper> _mockMapper = new Mock<IMapper>();
        private readonly BookRepository _bookRepository;

        public BookRepositoryTests()
        {
            _bookRepository = new BookRepository(_repositoryMock.Object,_mockMapper.Object);
        }

        [TestMethod]
        public async Task Handle_OnSuccess_ShouldGetBook()
        {
            //Arrange
            var books = new List<Book>();
            books.Add(new Book { AuthorName = "Test" });
            var booksDto = new List<BookDto>();
            booksDto.Add(new BookDto { AuthorName = "Test" });
            _repositoryMock.Setup(x => x.GetAllAsync()).ReturnsAsync(new List<Book>());
            _mockMapper.Setup(x => x.Map<List<BookDto>>(books)).Returns(booksDto);

            //Act
            var result = await _bookRepository.GetAsync();

            //Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public async Task Handle_OnFailure_ShouldFail()
        {
            //Arrange
            var books = new List<Book>();
            books.Add(new Book { AuthorName = "Test" });
            var booksDto = new List<BookDto>();
            booksDto.Add(new BookDto { AuthorName = "Test" });
            _repositoryMock.Setup(x => x.GetAllAsync()).ThrowsAsync(new ArgumentNullException());
            _mockMapper.Setup(x => x.Map<List<BookDto>>(books)).Throws(new AutoMapperMappingException());

            //Act
            var result = await _bookRepository.GetAsync();

            //Assert
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public async Task Handle_OnSuccess_ShouldGetBookById()
        {
            //Arrange
            var id = Guid.NewGuid();
            var book = new Book {Id = id, AuthorName = "Test" };
            var bookDto = new BookDto {Id = id, AuthorName = "Test" };
            _repositoryMock.Setup(x => x.GetByIdAsync(id)).ReturnsAsync(book);
            _mockMapper.Setup(x => x.Map<BookDto>(book)).Returns(bookDto);

            //Act
            var result = await _bookRepository.GetByIdAsync(id);

            //Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public async Task Handle_OnFailure_ShouldFailGetBookById()
        {
            //Arrange
            var id = Guid.NewGuid();
            var book = new Book { Id = id, AuthorName = "Test" };
            var bookDto = new BookDto { Id = id, AuthorName = "Test" };
            _repositoryMock.Setup(x => x.GetByIdAsync(id)).Throws(new ArgumentNullException());
            _mockMapper.Setup(x => x.Map<BookDto>(book)).Returns(bookDto);

            //Act
            var result = await _bookRepository.GetByIdAsync(id);

            //Assert
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public async Task Handle_OnSuccess_ShouldCreateBook()
        {
            //Arrange
            var id = Guid.NewGuid();
            var bookDto = new CreateBookDto { AuthorName = "Test" };
            var book = new Book { AuthorName = "Test" };
             _repositoryMock.Setup(x => x.AddAsync(book)).Returns(Task.CompletedTask);
            _mockMapper.Setup(x => x.Map<Book>(bookDto)).Returns(book);

            //Act
            var result = await _bookRepository.CreateAsync(bookDto);

            //Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public async Task Handle_OnFailure_ShouldFailToCreateBook()
        {
            //Arrange
            var id = Guid.NewGuid();
            var bookDto = new CreateBookDto { AuthorName = "Test" };
            var book = new Book { AuthorName = "Test" };
            _repositoryMock.Setup(x => x.AddAsync(book)).Throws(new Exception("Issue while processing"));
            _mockMapper.Setup(x => x.Map<Book>(bookDto)).Returns(book);

            //Act
            var result = await _bookRepository.CreateAsync(bookDto);

            //Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task Handle_OnSuccess_ShouldUpdateBook()
        {
            //Arrange
             
            var bookDto = new UpdateBookDto {Id = Guid.NewGuid(), AuthorName = "Test" };
            var book = new Book { Id = Guid.NewGuid(), AuthorName = "Test" };
            _repositoryMock.Setup(x => x.UpdateAsync(book));
            _mockMapper.Setup(x => x.Map<Book>(bookDto)).Returns(book);

            //Act
             await _bookRepository.UpdateAsync(bookDto);

            //Assert
            _repositoryMock.Verify(x => x.UpdateAsync(book), Times.Once);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public async Task Handle_OnFailure_ShouldFailToUpdateBook()
        {
            //Arrange

            var bookDto = new UpdateBookDto { Id = Guid.NewGuid(), AuthorName = "Test" };
            var book = new Book { Id = Guid.NewGuid(), AuthorName = "Test" };
            _repositoryMock.Setup(x => x.UpdateAsync(book)).Throws(new Exception());
            _mockMapper.Setup(x => x.Map<Book>(bookDto)).Returns(book);

            //Act
            await _bookRepository.UpdateAsync(bookDto);

            //Assert
            _repositoryMock.Verify(x => x.UpdateAsync(book), Times.Once);
        }
    }
}
