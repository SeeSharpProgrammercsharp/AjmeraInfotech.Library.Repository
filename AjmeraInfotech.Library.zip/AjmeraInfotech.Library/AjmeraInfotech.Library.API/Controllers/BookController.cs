﻿using AjmeraInfotech.Library.API.Infrastructure.Models;
using AjmeraInfotech.Library.AppCore.Book.Commands;
using AjmeraInfotech.Library.AppCore.Book.Queries;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AjmeraInfotech.Library.Common.Models.Request;
using AjmeraInfotech.Library.Common.Models.Response;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.API.Controllers
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/v1/[controller]")]
    [AllowAnonymous]
    public class BookController : ControllerBase
    {
        private readonly ILogger<BookController> _logger;
        private readonly IMediator _mediator;
        private readonly IMapper _mapper;

        public BookController(ILogger<BookController> logger, IMediator mediator, IMapper mapper)
        {
            _logger = logger;
            _mediator = mediator;
            _mapper = mapper;   
        }


        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<BookResponse>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status500InternalServerError)]
        public  async Task<IActionResult> GetAsync()
        {

            var response = await _mediator.Send(new GetBookQuery());
            return Ok(response);
            
        }

        [HttpGet("Id/{id}")]
        [ProducesResponseType(typeof(BookResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> GetByIdAsync([Required] Guid id)
        {
            var response = await _mediator.Send(new GetBookByIdQuery{ Id = id });
            return Ok(response);

        }


        [HttpPost]
        [ProducesResponseType(typeof(Guid), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> CreateAsync([Required]CreateBookRequest request)
        {
            var command = _mapper.Map<CreateBookCommand>(request);
            var response = await _mediator.Send(command);
            return Ok(response);

        }


        [HttpPut]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ApiErrorResponse), StatusCodes.Status500InternalServerError)]
        public async Task<IActionResult> UpdateAsync([Required]UpdateBookRequest request)
        {
            var command = _mapper.Map<UpdateBookCommand>(request);
            var response = await _mediator.Send(command);
            return Ok(response);
        }
    }
}
