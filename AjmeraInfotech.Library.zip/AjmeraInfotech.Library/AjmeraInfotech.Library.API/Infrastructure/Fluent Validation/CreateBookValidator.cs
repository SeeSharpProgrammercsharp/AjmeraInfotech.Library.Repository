﻿using AjmeraInfotech.Library.Common.Models.Request;
using FluentValidation;
using System;

namespace AjmeraInfotech.Library.API.Infrastructure.Fluent_Validation
{
    public class CreateBookValidator : AbstractValidator<CreateBookRequest>
    {
        public CreateBookValidator()
        {
            RuleFor(x => x.AuthorName).NotNull().NotEmpty().WithMessage("Author Name is required"); ;
            RuleFor(x => x.Name).NotNull().NotEmpty().WithMessage("Name is required"); ;
        }
    }
}
