﻿using AjmeraInfotech.Library.Common.Models.Request;
using FluentValidation;

namespace AjmeraInfotech.Library.API.Infrastructure.Fluent_Validation
{
    public class UpdateBookValidator :AbstractValidator<UpdateBookRequest>
    {
        public UpdateBookValidator()
        {
            RuleFor(x => x.AuthorName).NotEmpty().NotNull().WithMessage("Author Name is required");
            RuleFor(x => x.Name).NotEmpty().NotNull().WithMessage("Name is required");
            RuleFor(x => x.IsActive).NotNull().NotEmpty();
            RuleFor(x => x.IsDeleted).NotNull().NotEmpty();
            RuleFor(x => x.Id).NotNull().NotEmpty().WithMessage("Id is mandatory to update a book");
        }
    }
}
