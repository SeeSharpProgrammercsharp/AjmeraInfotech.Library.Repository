﻿namespace AjmeraInfotech.Library.API.Infrastructure.Models
{
    public class ApiErrorResponse
    {
        public string _code { get; set; }
        public string _Message { get; set; }
        public object _AdditionalInfo { get; set; }
        public ApiErrorResponse(string code, string message, object additionalInfo = null)
        {
            _code = code;   
            _Message = message; 
            _AdditionalInfo = additionalInfo;   
        }
    }
}
