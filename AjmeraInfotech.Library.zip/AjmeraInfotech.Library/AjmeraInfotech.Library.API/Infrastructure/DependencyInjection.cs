﻿using AjmeraInfotech.Library.AppCore.Book.Queries.Handlers;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using AutoMapper;

namespace AjmeraInfotech.Library.API.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection ConfigureIOC(this IServiceCollection services, IConfiguration config)
        {
            var mediatRTypes = new Type[] { typeof(GetBookQueryHandler), typeof(object) };
            services.AddMediatR(mediatRTypes);
            services.AddAutoMapper(cfg => { cfg.AllowNullCollections = true; }, AppDomain.CurrentDomain.GetAssemblies());

            return services;
        }
    }
}
