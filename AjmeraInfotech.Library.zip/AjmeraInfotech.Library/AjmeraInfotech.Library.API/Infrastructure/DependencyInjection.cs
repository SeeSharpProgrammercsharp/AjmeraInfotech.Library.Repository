﻿using AjmeraInfotech.Library.AppCore.Book.Queries.Handlers;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using AutoMapper;
using AjmeraInfotech.Library.API.Infrastructure.Fluent_Validation;
using AjmeraInfotech.Library.Common.Models.Request;
using FluentValidation;

namespace AjmeraInfotech.Library.API.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection ConfigureIOC(this IServiceCollection services, IConfiguration config)
        {
            var mediatRTypes = new Type[] { typeof(GetBookQueryHandler), typeof(object) };
            services.AddMediatR(mediatRTypes);
            services.AddAutoMapper(cfg => { cfg.AllowNullCollections = true; }, AppDomain.CurrentDomain.GetAssemblies());

            //Fluent Validation
            services.AddScoped<IValidator<CreateBookRequest>, CreateBookValidator>();
            return services;
        }
    }
}
