﻿using AjmeraInfotech.Library.AppCore.Book.Commands;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AjmeraInfotech.Library.Common.Models.Request;
using AjmeraInfotech.Library.Common.Models.Response;
using AjmeraInfotech.Library.Domain.Entities;
using AutoMapper;

namespace AjmeraInfotech.Library.API.Infrastructure.MappingProfiles
{
    public class BookProfile : Profile
    {
        public BookProfile()
        {
            CreateMap<Book, BookDto>(MemberList.Source);
            CreateMap<BookDto,BookResponse>(MemberList.Source);
            CreateMap<CreateBookDto,Book>().ReverseMap();   
            CreateMap<CreateBookCommand, CreateBookRequest>().ReverseMap();
            CreateMap<CreateBookDto, CreateBookCommand>().ReverseMap();
            CreateMap<UpdateBookDto, Book>().ReverseMap();
            CreateMap<UpdateBookCommand, UpdateBookRequest>().ReverseMap();
            CreateMap<UpdateBookDto, UpdateBookCommand>().ReverseMap();

        }
    }
}
