﻿using AjmeraInfotech.Library.API.Controllers;
using AjmeraInfotech.Library.AppCore.Book.Commands;
using AjmeraInfotech.Library.AppCore.Book.Queries;
using AjmeraInfotech.Library.Common.Models.Request;
using AjmeraInfotech.Library.Common.Models.Response;
using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.API.Tests.Controllers
{
    [TestClass]
    public class BookControllerTests
    {
        private readonly Mock<IMediator> _mediatorMock = new Mock<IMediator>();
        private readonly Mock<IMapper> _mapperMock = new Mock<IMapper>();
        private readonly ILogger<BookController> _logger;
        private readonly BookController _controller;

        public BookControllerTests()
        {
            _controller = new BookController(_logger, _mediatorMock.Object, _mapperMock.Object);
        }

        [TestMethod]
        public async Task GetAsync_Sucess()
        {
            //Arrange

            var response = new List<BookResponse>();
            response.Add(new BookResponse { AuthorName = "Test", Name = "Test" });

            _mediatorMock.Setup(x => x.Send(It.IsAny<GetBookQuery>(), It.IsAny<CancellationToken>())).ReturnsAsync(response);

            //Act
            var result = await _controller.GetAsync();

            //Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public async Task GetAsync_Fails()
        {
            //Arrange

            var response = new List<BookResponse>();
            response.Add(new BookResponse { AuthorName = "Test", Name = "Test" });

            _mediatorMock.Setup(x => x.Send(It.IsAny<GetBookQuery>(), It.IsAny<CancellationToken>())).Throws(new Exception());

            //Act
            var result = await _controller.GetAsync();

            //Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task GetByIdAsync_Sucess()
        {
            //Arrange
            var id = Guid.Parse("766053E3-7570-49ED-5CE7-08DAC1971FE7");

            var response = new BookResponse {Id =id, AuthorName = "Test", Name = "Test" };

            _mediatorMock.Setup(x => x.Send(It.IsAny<GetBookByIdQuery>(), It.IsAny<CancellationToken>())).ReturnsAsync(response);

            //Act
            var result = await _controller.GetByIdAsync(id);

            //Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(KeyNotFoundException))]
        public async Task GetByIdAsync_Fails()
        {
            //Arrange
            var id = Guid.Parse("766053E3-7570-49ED-5CE7-08DAC1971FE7");

            var response = new BookResponse { Id = id, AuthorName = "Test", Name = "Test" };

            _mediatorMock.Setup(x => x.Send(It.IsAny<GetBookByIdQuery>(), It.IsAny<CancellationToken>())).ThrowsAsync(new KeyNotFoundException("The Id provided does not exist"));

            //Act
            var result = await _controller.GetByIdAsync(id);

            //Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task CreateAsync_Sucess()
        {
            //Arrange
            var id = Guid.Parse("766053E3-7570-49ED-5CE7-08DAC1971FE7");

            var request = new CreateBookRequest { AuthorName = "Test", Name = "Test" };

            var requestCommand = new CreateBookCommand { AuthorName = "Test", Name = "Test" };

            var response = Guid.NewGuid();

            _mapperMock.Setup(x => x.Map<CreateBookCommand>(request)).Returns(requestCommand);

            _mediatorMock.Setup(x => x.Send(It.IsAny<CreateBookCommand>(), It.IsAny<CancellationToken>())).ReturnsAsync(response);

            //Act
            var result = await _controller.CreateAsync(request);

            //Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public async Task CreateAsync_Fail()
        {
            //Arrange
            var id = Guid.Parse("766053E3-7570-49ED-5CE7-08DAC1971FE7");

            var request = new CreateBookRequest { AuthorName = "Test", Name = "Test" };

            var requestCommand = new CreateBookCommand { AuthorName = "Test", Name = "Test" };

            var response = Guid.NewGuid();

            _mapperMock.Setup(x => x.Map<CreateBookCommand>(request)).Returns(requestCommand);

            _mediatorMock.Setup(x => x.Send(It.IsAny<CreateBookCommand>(), It.IsAny<CancellationToken>())).Throws(new Exception());

            //Act
            var result = await _controller.CreateAsync(request);

            //Assert
            Assert.IsNotNull(result);
        }


        [TestMethod]
        public async Task UpdateAsync_Sucess()
        {
            //Arrange
            var id = Guid.Parse("766053E3-7570-49ED-5CE7-08DAC1971FE7");

            var request = new UpdateBookRequest { AuthorName = "Test", Name = "Test" };

            var requestCommand = new UpdateBookCommand { AuthorName = "Test", Name = "Test" };

            var response = Unit.Value;

            _mapperMock.Setup(x => x.Map<UpdateBookCommand>(request)).Returns(requestCommand);

            _mediatorMock.Setup(x => x.Send(It.IsAny<UpdateBookCommand>(), It.IsAny<CancellationToken>())).ReturnsAsync(response);

            //Act
            var result = await _controller.UpdateAsync(request);

            //Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public async Task UpdateAsync_Fail()
        {
            //Arrange
            var id = Guid.Parse("766053E3-7570-49ED-5CE7-08DAC1971FE7");

            var request = new UpdateBookRequest { AuthorName = "Test", Name = "Test" };

            var requestCommand = new UpdateBookCommand { AuthorName = "Test", Name = "Test" };

            var response = Unit.Value;

            _mapperMock.Setup(x => x.Map<UpdateBookCommand>(request)).Returns(requestCommand);

            _mediatorMock.Setup(x => x.Send(It.IsAny<UpdateBookCommand>(), It.IsAny<CancellationToken>())).ThrowsAsync(new Exception());

            //Act
            var result = await _controller.UpdateAsync(request);

            //Assert
            Assert.IsNotNull(result);
        }
    }
}
