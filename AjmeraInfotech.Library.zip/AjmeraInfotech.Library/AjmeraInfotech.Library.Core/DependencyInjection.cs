﻿using System;

namespace AjmeraInfotech.Library.Core
{
    public class DependencyInjection
    {

    }
}
