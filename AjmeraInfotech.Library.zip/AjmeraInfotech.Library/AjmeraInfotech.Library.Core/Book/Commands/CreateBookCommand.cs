﻿using AjmeraInfotech.Library.Common.Models.Request;
using MediatR;
using System;

namespace AjmeraInfotech.Library.AppCore.Book.Commands
{
    public class CreateBookCommand : IRequest<Guid>
    {       
        public string Name { get; set; }

        public string AuthorName { get; set; }
       
    }
}
