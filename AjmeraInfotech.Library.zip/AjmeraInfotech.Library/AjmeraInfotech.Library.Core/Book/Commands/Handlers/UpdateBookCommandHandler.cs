﻿using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AppCore.Book.Commands.Handlers
{
    public class UpdateBookCommandHandler : IRequestHandler<UpdateBookCommand>
    {
        private readonly IMapper _mapper;
        private readonly IBookRepository _repository;
        public UpdateBookCommandHandler(IMapper mapper, IBookRepository repository)
        {
            _mapper = mapper;
            _repository = repository;
        }

        public async Task<Unit> Handle(UpdateBookCommand request, CancellationToken cancellationToken)
        {
            var requestDto = _mapper.Map<UpdateBookDto>(request);
            await _repository.UpdateAsync(requestDto);
            return Unit.Value;
        }
    }
}
