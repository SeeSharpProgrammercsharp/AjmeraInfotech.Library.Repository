﻿using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AppCore.Book.Commands.Handlers
{
    public class CreateBookCommandHandler : IRequestHandler<CreateBookCommand,Guid>
    {
        
        private readonly IBookRepository _repository;
        private readonly IMapper _mapper;
        public CreateBookCommandHandler(IBookRepository repository, IMapper mapper)
        {
            _mapper = mapper;
            _repository = repository;
        }

        public async Task<Guid> Handle(CreateBookCommand request, CancellationToken cancellationToken)
        {
            var requestDto = _mapper.Map<CreateBookDto>(request);
            return await _repository.CreateAsync(requestDto);
        }
    }
}
