﻿using AjmeraInfotech.Library.Common.Models.Response;
using MediatR;
using System;

namespace AjmeraInfotech.Library.AppCore.Book.Queries
{
    public class GetBookByIdQuery : IRequest<BookResponse>
    {
        public Guid Id { get; set; }
    }
}
