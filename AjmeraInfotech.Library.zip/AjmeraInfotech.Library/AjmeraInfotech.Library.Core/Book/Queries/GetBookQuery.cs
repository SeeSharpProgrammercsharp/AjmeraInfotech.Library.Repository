﻿using AjmeraInfotech.Library.Common.Models.Dtos;
using AjmeraInfotech.Library.Common.Models.Response;
using MediatR;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace AjmeraInfotech.Library.AppCore.Book.Queries
{
    public class GetBookQuery : IRequest<IEnumerable<BookResponse>>
    {
    }
}
