﻿using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.Common.Models.Response;
using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AppCore.Book.Queries.Handlers
{
    public class GetBookByIdQueryHandler : IRequestHandler<GetBookByIdQuery,BookResponse>
    {
        private readonly IMapper _mapper;

        private readonly IBookRepository _repository;
        public GetBookByIdQueryHandler(IMapper mapper, IBookRepository repository)
        {
            _mapper = mapper;
            _repository = repository;
        }

        public async Task<BookResponse> Handle(GetBookByIdQuery request, CancellationToken cancellationToken)
        {
            var response = await _repository.GetByIdAsync(request.Id);
            if (response == null)
            {
                throw new KeyNotFoundException("The Id provided does not exist");
            }
            return _mapper.Map<BookResponse>(response);
        }
    }
}
