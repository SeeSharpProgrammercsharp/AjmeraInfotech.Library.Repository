﻿using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AjmeraInfotech.Library.Common.Models.Response;
using AutoMapper;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AppCore.Book.Queries.Handlers
{
    public class GetBookQueryHandler : IRequestHandler<GetBookQuery, IEnumerable<BookResponse>>
    {
        private readonly IBookRepository _repository;
        private readonly IMapper _mapper;
        public GetBookQueryHandler(IBookRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<BookResponse>> Handle(GetBookQuery request, CancellationToken cancellationToken)
        {
           var response = await _repository.GetAsync();
            return _mapper.Map<IEnumerable<BookResponse>>(response);
        }
    }
}
