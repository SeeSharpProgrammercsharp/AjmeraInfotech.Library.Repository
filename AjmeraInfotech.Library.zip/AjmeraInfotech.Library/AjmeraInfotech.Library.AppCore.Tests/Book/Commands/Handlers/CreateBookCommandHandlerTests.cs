﻿using AjmeraInfotech.Library.AppCore.Book.Commands;
using AjmeraInfotech.Library.AppCore.Book.Commands.Handlers;
using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AutoMapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AppCore.Tests.Book.Commands.Handlers
{
    [TestClass]
    public class CreateBookCommandHandlerTests
    {

        private readonly Mock<IBookRepository> _repositoryMock = new Mock<IBookRepository>();
        private readonly Mock<IMapper> _mapperMock = new Mock<IMapper>();
        private readonly CreateBookCommandHandler _handler;

        public CreateBookCommandHandlerTests()
        {
            _handler = new CreateBookCommandHandler(_repositoryMock.Object, _mapperMock.Object);
        }

        [TestMethod]
        public async Task Handle_OnSuccess_ShouldCallCreate()
        {
            //Arrange
            var command = new CreateBookCommand()
            {
                AuthorName = "Test",
                Name = "Test"
            };

            //Act
            var response = await _handler.Handle(command, CancellationToken.None);

            //Verify

            _repositoryMock.Verify(x => x.CreateAsync(It.IsAny<CreateBookDto>()), Times.Once);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public async Task Handle_OnSuccess_ShouldCallCreate_Fail()
        {
            //Arrange
            var command = new CreateBookCommand()
            {
                AuthorName = "Test",
                Name = "Test"
            };
            _repositoryMock.Setup(x => x.CreateAsync(It.IsAny<CreateBookDto>())).ThrowsAsync(new ArgumentNullException());

            //Act
            var response = await _handler.Handle(command, CancellationToken.None);

            //Verify

            Assert.IsNotNull(response);
        }
    }
}
