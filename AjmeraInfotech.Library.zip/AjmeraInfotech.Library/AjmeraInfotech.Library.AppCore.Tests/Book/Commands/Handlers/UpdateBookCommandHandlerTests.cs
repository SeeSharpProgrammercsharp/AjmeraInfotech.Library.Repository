﻿using AjmeraInfotech.Library.AppCore.Book.Commands;
using AjmeraInfotech.Library.AppCore.Book.Commands.Handlers;
using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AutoMapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace AjmeraInfotech.Library.AppCore.Tests.Book.Commands.Handlers
{
    [TestClass]
    public class UpdateBookCommandHandlerTests
    {
        private readonly Mock<IBookRepository> _repositoryMock = new Mock<IBookRepository>();
        private readonly Mock<IMapper> _mapperMock = new Mock<IMapper>();
        private readonly UpdateBookCommandHandler _handler;

        public UpdateBookCommandHandlerTests()
        {
            _handler = new UpdateBookCommandHandler(_mapperMock.Object,_repositoryMock.Object);
        }

        [TestMethod]
        public async Task Handle_OnSuccess_ShouldCallUpdate()
        {
            //Arrange
            var command = new UpdateBookCommand()
            {
                AuthorName = "Test",
                Name = "Test"
            };

            //Act
            var response = await _handler.Handle(command, CancellationToken.None);

            //Verify

            _repositoryMock.Verify(x => x.UpdateAsync(It.IsAny<UpdateBookDto>()), Times.Once);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public async Task Handle_OnSuccess_ShouldCallUpdate_Fail()
        {
            //Arrange
            var command = new UpdateBookCommand()
            {
                AuthorName = "Test",
                Name = "Test"
            };
            _repositoryMock.Setup(x => x.UpdateAsync(It.IsAny<UpdateBookDto>())).ThrowsAsync(new ArgumentNullException());

            //Act
            var response = await _handler.Handle(command, CancellationToken.None);

            //Verify

            Assert.IsNotNull(response);
        }
    }
}
