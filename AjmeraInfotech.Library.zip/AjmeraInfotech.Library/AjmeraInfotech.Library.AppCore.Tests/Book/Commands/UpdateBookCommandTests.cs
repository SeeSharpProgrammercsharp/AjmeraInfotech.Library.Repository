﻿using AjmeraInfotech.Library.AppCore.Book.Commands.Handlers;
using AjmeraInfotech.Library.AppCore.Book.Commands;
using AjmeraInfotech.Library.AzureDB.Interfaces;
using AutoMapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using AjmeraInfotech.Library.Common.Models.Dtos;
using MediatR;

namespace AjmeraInfotech.Library.AppCore.Tests.Book.Commands
{
    [TestClass]
    public class UpdateBookCommandTests
    {
        private readonly UpdateBookCommandHandler _handler;
        private readonly Mock<IBookRepository> _repositoryMock = new Mock<IBookRepository>();
        private readonly Mock<IMapper> _mapperMock = new Mock<IMapper>();

        public UpdateBookCommandTests()
        {
            _handler = new UpdateBookCommandHandler(_mapperMock.Object, _repositoryMock.Object);
        }

        [TestMethod]
        public async Task Handle_OnSuccess_ShouldCallCreate()
        {
            //Arrange
            var command = new UpdateBookCommand()
            {
                AuthorName = "Test",
                Name = "Test"
            };

            //Act
            var response = await _handler.Handle(command, CancellationToken.None);

            // Assert
            _repositoryMock.Verify(x => x.UpdateAsync(It.IsAny<UpdateBookDto>()), Times.Once);
        }

        [TestMethod]
        public async Task Handle_OnSuccess_ShouldCallCreate_1()
        {
            //Arrange
            var response = Unit.Value;

            var command = new UpdateBookCommand()
            {
                AuthorName = "Test",
                Name = "Test"
            };

            _repositoryMock.Setup(x => x.UpdateAsync(It.IsAny<UpdateBookDto>())).Returns(Task.CompletedTask);


            //Act
            var result = await _handler.Handle(command, CancellationToken.None);


            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        [ExpectedException(typeof(Exception))]
        public async Task Handle_OnSuccess_ShouldCallCreate_Fails()
        {
            //Arrange
            var id = Guid.NewGuid();

            var command = new UpdateBookCommand()
            {
                AuthorName = "Test",
                Name = "Test"
            };

            _repositoryMock.Setup(x => x.UpdateAsync(It.IsAny<UpdateBookDto>())).ThrowsAsync(new Exception());


            //Act
            var response = await _handler.Handle(command, CancellationToken.None);


            // Assert
            Assert.IsNotNull(response);
        }
    }
}
