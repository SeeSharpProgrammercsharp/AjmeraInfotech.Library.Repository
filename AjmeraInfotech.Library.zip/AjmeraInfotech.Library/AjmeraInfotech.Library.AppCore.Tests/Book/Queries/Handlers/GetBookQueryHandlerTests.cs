﻿using AjmeraInfotech.Library.AppCore.Book.Queries;
using AjmeraInfotech.Library.AppCore.Book.Queries.Handlers;
using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AjmeraInfotech.Library.Common.Models.Response;
using AutoMapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AppCore.Tests.Book.Queries.Handlers
{
    [TestClass]
    public class GetBookQueryHandlerTests
    {
        private readonly Mock<IBookRepository> _repositoryMock = new Mock<IBookRepository>();
        private readonly Mock<IMapper> _mapperMock = new Mock<IMapper>();
        private GetBookQueryHandler _handler;
        public GetBookQueryHandlerTests()
        {
            _handler = new GetBookQueryHandler(_repositoryMock.Object,_mapperMock.Object);
        }

        [TestMethod]
        public async Task Handle_OnSuccess_GetBooks()
        {
            //Arrange
            var dto = new List<BookDto>(); 
            dto.Add(new BookDto{ AuthorName = "Test" });
            var response = new List<BookResponse>();
            response.Add(new BookResponse{ AuthorName = "Test" });
            var request = new GetBookQuery();
            _mapperMock.Setup(x => x.Map<BookResponse>(dto));
            _repositoryMock.Setup(x => x.GetAsync()).ReturnsAsync(dto);

            //Act
            var result = _handler.Handle(request, CancellationToken.None);

            //Assert
            Assert.IsNotNull(result);

        }

        [TestMethod]
        [ExpectedException(typeof(AutoMapperMappingException))]
        public async Task Handle_OnFailure_GetBooks()
        {
            //Arrange
            var dto = new List<BookDto>();
            dto.Add(new BookDto { AuthorName = "Test" });
            var response = new List<BookResponse>();
            response.Add(new BookResponse { AuthorName = "Test" });
            var request = new GetBookQuery();
            _mapperMock.Setup(x => x.Map<BookResponse>(dto)).Throws(new AutoMapperMappingException());
            _repositoryMock.Setup(x => x.GetAsync()).Throws(new AutoMapperMappingException());

            //Act
            var result = await _handler.Handle(request, CancellationToken.None);

            //Assert
            Assert.IsNotNull(result);

        }
    }
}
