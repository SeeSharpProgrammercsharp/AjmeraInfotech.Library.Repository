﻿using AjmeraInfotech.Library.AppCore.Book.Queries;
using AjmeraInfotech.Library.AppCore.Book.Queries.Handlers;
using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AjmeraInfotech.Library.Common.Models.Response;
using AutoMapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace AjmeraInfotech.Library.AppCore.Tests.Book.Queries.Handlers
{
    [TestClass]
    public class GetBookQueryByIdHandlerTests
    {
        private readonly Mock<IBookRepository> _repositoryMock = new Mock<IBookRepository>();
        private readonly Mock<IMapper> _mapperMock = new Mock<IMapper>();
        private GetBookByIdQueryHandler _handler;
        public GetBookQueryByIdHandlerTests()
        {
            _handler = new GetBookByIdQueryHandler(_mapperMock.Object, _repositoryMock.Object);
        }

        [TestMethod]
        public async Task Handle_OnSuccess_GetBook()
        {
            //Arrange
            var id = Guid.NewGuid();
            var dto = new BookDto {Id = id, AuthorName = "Test" };
            var response = new BookResponse { AuthorName = "Test" };
            var request = new GetBookByIdQuery { Id = id};
            _mapperMock.Setup(x => x.Map<BookResponse>(dto)).Returns(response);
            _repositoryMock.Setup(x => x.GetByIdAsync(request.Id)).ReturnsAsync(dto);

            //Act
            var result =await _handler.Handle(request, CancellationToken.None);

            //Assert
            Assert.IsNotNull(result);

        }

        [TestMethod]
        [ExpectedException(typeof(KeyNotFoundException))]
        public async Task Handle_OnFailure_GetBook()
        {
            //Arrange
            var id = Guid.NewGuid();
            var dto = new BookDto { AuthorName = "Test" };
            var response = new BookResponse { AuthorName = "Test" };
            var request = new GetBookByIdQuery();
            _mapperMock.Setup(x => x.Map<BookResponse>(dto)).Throws(new AutoMapperMappingException());
            _repositoryMock.Setup(x => x.GetByIdAsync(id)).Throws(new KeyNotFoundException());

            //Act
            var result = await _handler.Handle(request, CancellationToken.None);

            //Assert
            Assert.IsNotNull(result);

        }
    }
}
