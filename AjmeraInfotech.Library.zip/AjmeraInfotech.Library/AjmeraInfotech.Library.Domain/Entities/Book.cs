﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AjmeraInfotech.Library.Domain.Entities
{
    public class Book : BaseEntity
    {
        public string Name { get; set; }

        public string AuthorName { get; set; }
    }
}
