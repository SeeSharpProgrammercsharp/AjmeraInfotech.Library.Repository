﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AjmeraInfotech.Library.Domain.Entities
{
    public abstract class BaseEntity
    {
        public Guid Id { get; set; }

        /// <summary>
        /// Is entity in active mode
        /// </summary>
       // [Filterable(nameof(IsActive))]
        public virtual bool IsActive { get; set; }
        /// <summary>
        /// Is entity deleted
        /// </summary>
        public virtual bool IsDeleted { get; set; }
        /// <summary>
        /// Date when entity was created
        /// </summary>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Date when the entity was modified
        /// </summary>
        public DateTime ModifiedDate { get; set; }
    }
}
