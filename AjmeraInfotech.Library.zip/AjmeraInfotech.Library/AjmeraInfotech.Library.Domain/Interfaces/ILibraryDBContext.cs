﻿using AjmeraInfotech.Library.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace AjmeraInfotech.Library.Domain.Interfaces
{
    public interface ILibraryDBContext
    {
        DbSet<Book> Books { get; set; }

        DbSet<TEntity> Set<TEntity>()
            where TEntity : class;

        EntityEntry Entry(object entity);

        Task<int> SaveChangesAsync(CancellationToken cancellationToken);

        ChangeTracker ChangeTracker { get; }
    }
}
