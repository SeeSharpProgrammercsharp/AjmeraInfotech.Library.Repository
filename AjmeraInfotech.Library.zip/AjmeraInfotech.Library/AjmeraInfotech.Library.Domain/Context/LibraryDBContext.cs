﻿using AjmeraInfotech.Library.Domain.Entities;
using AjmeraInfotech.Library.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace AjmeraInfotech.Library.Domain.Context
{
    public class LibraryDBContext : DbContext, ILibraryDBContext
    {
        public LibraryDBContext(DbContextOptions<LibraryDBContext> options) : base(options)
        {

        }
       public DbSet<Book> Books { get; set; }
    }
}
