﻿using AjmeraInfotech.Library.Common.Models.Dtos;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AzureDB.Interfaces
{
    public interface IBookRepository
    {
        Task<IEnumerable<BookDto>> GetAsync();

        Task<BookDto> GetByIdAsync(Guid id);

        Task<Guid> CreateAsync(CreateBookDto request);

        Task UpdateAsync(UpdateBookDto request);
    }
}
