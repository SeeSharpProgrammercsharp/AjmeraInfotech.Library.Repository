﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AzureDB.Interfaces
{
    public interface IGenericRepository<TEntity>
        where TEntity : class
    {
        Task AddAsync(TEntity entity);

        Task<IEnumerable<TEntity>> GetAllAsync();

        Task<TEntity> GetByIdAsync(Guid id);

        void RemoveAsync(TEntity entity);      

        Task SaveChangesAsync();
        void UpdateAsync(TEntity entity);

    }
}
