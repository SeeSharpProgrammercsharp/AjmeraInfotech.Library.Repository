﻿using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.AzureDB.Repositories;
using AjmeraInfotech.Library.Domain.Context;
using AjmeraInfotech.Library.Domain.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace AjmeraInfotech.Library.AzureDB
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructureAzureDb(this IServiceCollection services)
        {
            services.AddScoped(typeof(IBookRepository), typeof(BookRepository));
            services.AddScoped(typeof(IGenericRepository<>), typeof(AuditingGenericRepository<>));
            services.AddScoped(typeof(ILibraryDBContext), typeof(LibraryDBContext));
            return services;
        }
    }
}
