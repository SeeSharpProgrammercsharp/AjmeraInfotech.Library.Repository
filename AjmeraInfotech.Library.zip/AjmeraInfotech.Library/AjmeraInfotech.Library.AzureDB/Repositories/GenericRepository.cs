﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Linq;
using System.Text;
using AjmeraInfotech.Library.Domain.Context;
using Microsoft.EntityFrameworkCore;
using AjmeraInfotech.Library.Domain.Interfaces;
using System.Threading.Tasks;
using System.Threading;
using AjmeraInfotech.Library.AzureDB.Interfaces;

namespace AjmeraInfotech.Library.AzureDB.Repositories
{
    public class GenericRepository<TEntity> : IGenericRepository<TEntity>  where TEntity : class
    {
        protected readonly ILibraryDBContext context;
        internal DbSet<TEntity> entityItems;
        public GenericRepository(ILibraryDBContext context)
        {
            this.context = context;
            this.entityItems = this.context.Set<TEntity>();
        }
        public async Task AddAsync(TEntity entity)
        {
            await this.entityItems.AddAsync(entity);
        }      

        public async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            return await this.entityItems.ToListAsync();
        }

        public async Task<TEntity> GetByIdAsync(Guid id)
        {
            return await this.entityItems.FindAsync(id);
        }

        public void UpdateAsync(TEntity entity)
        {
            var entry = this.context.Entry(entity);
            entry.State = EntityState.Modified;
        }     

        public void RemoveAsync(TEntity entity)
        {
            this.entityItems.Remove(entity);
        }       
        public virtual async Task SaveChangesAsync()
        {
            await this.context.SaveChangesAsync(CancellationToken.None);
        }
    }
}
