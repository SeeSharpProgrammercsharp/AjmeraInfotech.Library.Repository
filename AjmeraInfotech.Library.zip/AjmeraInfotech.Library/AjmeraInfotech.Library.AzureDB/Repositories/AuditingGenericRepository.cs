﻿using AjmeraInfotech.Library.Domain.Entities;
using AjmeraInfotech.Library.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AzureDB.Repositories
{
    public sealed class AuditingGenericRepository<TEntity> : GenericRepository<TEntity>
        where TEntity : class
    {
        public AuditingGenericRepository(ILibraryDBContext context)
            : base(context)
        {
        }

        public override Task SaveChangesAsync()
        {
            var trackStates =
                new[] { EntityState.Added, EntityState.Modified, EntityState.Deleted };
            var changes = this.context.ChangeTracker.Entries()
                .Where(x => trackStates.Contains(x.State)).ToList();

            foreach (var change in changes)
            {
                if (change.Entity is BaseEntity auditableItem)
                {
                    switch (change.State)
                    {
                        case EntityState.Added:
                            auditableItem.CreatedDate = DateTime.UtcNow;
                            auditableItem.ModifiedDate = DateTime.UtcNow;
                            auditableItem.IsActive = true;
                            auditableItem.IsDeleted = false;
                            break;
                        case EntityState.Modified:
                            //auditableItem.CreatedDate = change.Entity.
                            auditableItem.ModifiedDate = DateTime.UtcNow;
                            break;
                    }
                }
            }

            return base.SaveChangesAsync();
        }
    }
}
