﻿using AjmeraInfotech.Library.AzureDB.Interfaces;
using AjmeraInfotech.Library.Common.Models.Dtos;
using AjmeraInfotech.Library.Domain.Entities;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace AjmeraInfotech.Library.AzureDB.Repositories
{
    public class BookRepository : IBookRepository
    {
        private readonly IGenericRepository<Book> _genericRepository;
        private readonly IMapper _mapper;

        public BookRepository(IGenericRepository<Book> genericRepository, IMapper mapper)
        {
            _genericRepository = genericRepository;
            _mapper = mapper;
        }
        public async Task<IEnumerable<BookDto>> GetAsync()
        {
            var response = await _genericRepository.GetAllAsync();
            return _mapper.Map<IEnumerable<BookDto>>(response);
        }       

        public async Task<BookDto> GetByIdAsync(Guid id)
        {
            var response = await _genericRepository.GetByIdAsync(id);
            return _mapper.Map<BookDto>(response);
        }

        public async Task<Guid> CreateAsync(CreateBookDto request)
        {
            var entity = _mapper.Map<Book>(request);
            await _genericRepository.AddAsync(entity);
            await this._genericRepository.SaveChangesAsync();
            return entity.Id;
        }

        public async Task UpdateAsync(UpdateBookDto request)
        {
            var entity = _mapper.Map<Book>(request);
              _genericRepository.UpdateAsync(entity);
            await this._genericRepository.SaveChangesAsync();            
        }
    }
}
