﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AjmeraInfotech.Library.Common.Models.Request
{
    public class CreateBookRequest
    {       
        public string Name { get; set; }

        public string AuthorName { get; set; }
        
    }
}
